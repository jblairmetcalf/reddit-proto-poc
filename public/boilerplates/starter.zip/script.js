const btn = document.getElementById("toggleBtn");
const counter = document.getElementById("counter");
let active = false;
let count = 0;

btn.addEventListener("click", () => {
  active = !active;
  count++;
  btn.textContent = active ? "Active!" : "Toggle State";
  btn.classList.toggle("active", active);
  counter.textContent = `Toggled ${count} time${count === 1 ? "" : "s"}`;
});